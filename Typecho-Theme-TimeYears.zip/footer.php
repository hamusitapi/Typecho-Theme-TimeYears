<footer class="mdui-center mdui-p-a-1 mdui-shadow-8">
    <div class="mdui-row mdui-p-a-1">
        <div>TimeYears.cn &copy; 2019</div><hr/>
        <div>Power by <a href="http://typecho.org" target="_blank">Typecho</a></div>
    </div>
</footer>
</div>
</body>
</html>
