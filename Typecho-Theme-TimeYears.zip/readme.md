# Typecho-Theme-TimeYears 
主题演示站点：http://timeyears.cn/

- 时岁主题-简洁MD风  
- 采用MDUI，尽力做到响应式布局  
- 学业问题预期完整版需4个月  

更新情况：  
- 2019/4/7 - 15%

爆肝之作，敬请期待！  
timeyears.cn &copy; 2019
